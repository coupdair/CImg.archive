----------------------------------------------------------------------------- 
 Compilation on Windows using Visual Studio CPP 6 can be
 done using the project file located in this directory. By default, 
 the example compiled is 'examples/CImg_demo.cpp', but just replace it by
 another source file in 'examples/' to compile the desired code.
-----------------------------------------------------------------------------