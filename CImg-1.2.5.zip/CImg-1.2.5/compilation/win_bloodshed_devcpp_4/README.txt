----------------------------------------------------------------
 Compilation with Dev-Cpp requires to link the code with the
 standart 'gdi32.lib' library that you can find in the
 'Dev-Cpp/lib' directory. In the following .dev projects,
 this library has been specified to be in 'C:\Dev-Cpp\lib'.
 If this is not the path of your current Dev-Cpp version, you
 will have to modify it, in the menu :
 'Project/Projet Options/Parameters'.
----------------------------------------------------------------
