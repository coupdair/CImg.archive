----------------------------------------------------------------------------- 
 Compilation on Unix is done through a Makefile present in the directory :
 'examples/'. Just go there and type 'make', or use the small .sh scripts
 provided in this directory :
 '. compile_linux.sh' for Linux architectures, or
 '. compile_solaris.sh' for Solaris architectures.
-----------------------------------------------------------------------------