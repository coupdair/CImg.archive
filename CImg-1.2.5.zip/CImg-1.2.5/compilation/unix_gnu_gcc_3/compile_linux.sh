#!/bin/sh
cd ../../examples
make olinux
