#!/bin/sh
cd ../../examples
make osolaris
