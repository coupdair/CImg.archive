--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
                            ____  _   _  ____
                           (_  _)( )_( )( ___)
                             )(   ) _ (  )__)
                            (__) (_) (_)(____)
    ___  ____  __  __  ___     __    ____  ____  ____    __    ____  _  _
   / __)(_  _)(  \/  )/ __)   (  )  (_  _)(  _ \(  _ \  /__\  (  _ \( \/ )
  ( (__  _)(_  )    (( (_-.    )(__  _)(_  ) _ < )   / /(__)\  )   / \  /
   \___)(____)(_/\/\_)\___/   (____)(____)(____/(_)\_)(__)(__)(_)\_) (__)


                    C++ Template Image Processing Library

                       ( http://cimg.sourceforge.net )

                                   v.1.2.5

--------------------------------------------------------------------------------

# Summary
#---------

  The CImg Library is an open-source C++ toolkit for image processing.
  It consists in a single header file 'CImg.h' providing a set of C++ classes
  and methods that can be used in your own sources, to load/save, process
  and display images. Very portable (Unix/X11,Windows, MacOS X, FreeBSD,..),
  efficient, easy to use, it's a pleasant toolkit for coding image processing
  stuffs in C++.

# Author
#--------

  David Tschumperle  ( http://www.greyc.ensicaen.fr/~dtschump/ )

  with the help of various contributors, including :

  - Haz-Edine Assemlal
  - Vincent Barra
  - Yohan Bentolila
  - Jerome Boulanger
  - Frederic Devernay
  - Fran�ois-Xavier Dup�
  - Eric Fausett
  - Jean-Marie Favreau
  - Sebastien Fourey
  - Alexandre Fournier
  - Vincent Garcia
  - Jean-Daniel Guyot
  - Matt Hanson
  - Christoph Hormann
  - Werner Jainek
  - Daniel Kondermann
  - Pierre Kornprobst
  - Orges Leka
  - Francois Lauze
  - Xie Long
  - Thomas Martin
  - Jean Martinot
  - Renaud Peteri
  - Martin Petricek
  - Paolo Prete
  - Konstantin Spirin
  - Grzegorz Szwoch
  - Thierry Thomas
  - Yu-En-Yun
  - Vo Duc Khanh
  - Bug Zhao

# Institution
#-------------

 GREYC Image / CNRS UMR 6072 / FRANCE

 The CImg Library project started in 2000, at the INRIA-Sophia
 Antipolis/France (http://www-sop.inria.fr/) during my PhD thesis.
 Since October 2004, it is maintained and developed in the Image team of
 the GREYC Lab (CNRS, UMR 6072), in Caen/France.
 Team web page : http://www.greyc.ensicaen.fr/EquipeImage/

# License
#---------

 The source code of the CImg Library is distributed under
 two distinct licenses :

 - The main library file 'CImg.h' is distributed under the CeCiLL-C license
   (file 'Licence_CeCILL-C_V1-en.txt').
   This is a Free-Software license, adapted to the distribution of library
   library components, and is close in its terms to the well known LGPL license
   (the 'CImg.h' file can thus be used in closed-source products under certain
    conditions, please read carefully the license file).

 - Most of the other files are distributed under the CeCiLL license
   (file 'Licence_CeCILL_V2-en.txt').
   This License is a Free-Software license, compatible with the GPL license
   (so using those files in closed-source project is strictly forbidden).

 These two CeCiLL licenses ( http://www.cecill.info/index.en.html ) have been
 created under the supervision of the three biggest research institutions on
 computer sciences in France :

   - CNRS  ( http://www.cnrs.fr/ )
   - CEA   ( http://www.cea.fr/ )
   - INRIA ( http://www.inria.fr/ )

 You have to RESPECT these licenses. More particularly, please carefully read
 the license terms before using the CImg library in commercial products.

# Package structure :
#--------------------

  The directory CImg/ is organized as follows :

  - CImg.h                     : The single (header) file of the library itself.
  - CHANGES.txt                : A list of changes between CImg versions.
  - Licence_CeCILL-C_V1-en.txt : The CeCiLL-C license governing the use of 'CImg.h'.
  - Licence_CeCILL_V2-en.txt   : The CeCiLL license governing the use of other CImg files.
  - README.txt                 : This file.

  - documentation/ : Directory containing a copy of the CImg web page in html
                     format. The documentation has been generated
		     automatically with the tool 'doxygen' (www.doxygen.org).
		     Note that you can also access the documentation online at
		     http://cimg.sourceforge.net/

  - compilation/   : Directory containing several sub-directories that provide
                     project files or scripts to ease the compilation of the
		     examples, with various C++ compilers on Unix and Windows.

  - plugins/       : Directory containing CImg plug-ins which are basically files
                     that add extra functions to the CImg library.

  - examples/      : Directory containing a lot of example programs performing
                     various stuffs, based on the CImg library.

# Getting started
#-----------------

  First, you should try to compile the different examples provided in the
  'examples/' directory. Look at the 'compilation/' directory to ease this
  compilation step on different plateforms. Then, you can look at the
  documentation 'documentation/head.html' and the complete reference
  'documentation/reference/index.html' to learn more about CImg functions and
  classes. Finally, you can participate to the 'Forum' section of the
  CImg web page and ask for help if needed.

------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
