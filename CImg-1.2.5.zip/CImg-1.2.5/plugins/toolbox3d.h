/*-----------------------------------------------------------------------------

  File        : toolbox3d.h

  Description : CImg plug-in adding useful functions to create 3D objects
                and operate on them.

  Copyright  : David Tschumperle - http://www.greyc.ensicaen.fr/~dtschump/

  This software is governed by the CeCILL  license under French law and
  abiding by the rules of distribution of free software.  You can  use,
  modify and/ or redistribute the software under the terms of the CeCILL
  license as circulated by CEA, CNRS and INRIA at the following URL
  "http://www.cecill.info".

  As a counterpart to the access to the source code and  rights to copy,
  modify and redistribute granted by the license, users are provided only
  with a limited warranty  and the software's author,  the holder of the
  economic rights,  and the successive licensors  have only  limited
  liability.

  In this respect, the user's attention is drawn to the risks associated
  with loading,  using,  modifying and/or developing or reproducing the
  software by the user in light of its specific status of free software,
  that may mean  that it is complicated to manipulate,  and  that  also
  therefore means  that it is reserved for developers  and  experienced
  professionals having in-depth computer knowledge. Users are therefore
  encouraged to load and test the software's suitability as regards their
  requirements in conditions enabling the security of their systems and/or
  data to be ensured and,  more generally, to use and operate it in the
  same conditions as regards security.

  The fact that you are presently reading this means that you have had
  knowledge of the CeCILL license and that you accept its terms.

  ------------------------------------------------------------------------------*/

#ifndef cimg_plugin_toolbox3d
#define cimg_plugin_toolbox3d

//! Get a cube.
template<typename tf> static CImg cube(CImgList<tf>& primitives) {
  const double a = 0.5;
  primitives.assign(6,1,4,1,1, 0,3,2,1, 4,5,6,7, 0,1,5,4, 3,7,6,2, 0,4,7,3, 1,2,6,5);
  return CImg<T>(8,3,1,1, -a,a,a,-a,-a,a,a,-a,-a,-a,a,a,-a,-a,a,a,-a,-a,-a,-a,a,a,a,a);
}

//! Get a cone.
template<typename tf> static CImg cone(CImgList<tf>& primitives, const unsigned int subdivisions=16) {
  CImgList<T> points(3,1,3,1,1, 0.0,0.0,0.5,0.0,0.0,-0.5,0.5,0.0,-0.5);
  primitives.assign();
  const float delta = 360.0f/subdivisions;
  for (float i = 0.0f; i<360.0f; i+=delta) {
    const float angle = (float)(i*cimg::PI/180);
    points.insert(CImg<T>::vector((T)(0.5f*std::cos(angle)),(T)(0.5f*std::sin(angle)),(T)(-0.5f)));
    primitives.insert(CImg<tf>::vector(0,points.size-2,points.size-1)).
      insert(CImg<tf>::vector(1,points.size-1,points.size-2));
  }
  primitives.insert(CImg<tf>::vector(0,points.size-1,2)).
    insert(CImg<tf>::vector(1,2,points.size-1));
  return points.get_append('x');
}

//! Get a cylinder.
template<typename tf> static CImg cylinder(CImgList<tf>& primitives, const unsigned int subdivisions=16) {
  CImgList<T> points(4,1,3,1,1, 0.0,0.0,0.5, 0.0,0.0,-0.5, 0.5,0.0,0.5, 0.5,0.0,-0.5);
  primitives.assign();
  const float delta = 360.0f/subdivisions;
  for (float i = 0.0f; i<360.0f; i+=delta) {
    const double
      angle = i*cimg::PI/180,
      x = 0.5f*std::cos(angle),
      y = 0.5f*std::sin(angle);
    points.insert(CImg<T>::vector(x,y,0.5)).
      insert(CImg<T>::vector(x,y,-0.5));
    primitives.insert(CImg<tf>::vector(1,points.size-1,points.size-3)).
      insert(CImg<tf>::vector(0,points.size-4,points.size-2)).
      insert(CImg<tf>::vector(points.size-1,points.size-2,points.size-4,points.size-3));
  }
  primitives.insert(CImg<tf>::vector(1,3,points.size-1)).
    insert(CImg<tf>::vector(2,0,points.size-2)).
    insert(CImg<tf>::vector(3,2,points.size-2,points.size-1));
  return points.get_append('x');
}

//! Get a torus.
template<typename tf> static CImg torus(CImgList<tf>& primitives, const float inner_radius=0.25f,
                                        const unsigned int subdivisions1=16, const unsigned int subdivisions2=8) {
  CImgList<T> points;
  primitives.assign();
  for (unsigned int v=0; v<subdivisions1; ++v)
    for (unsigned int u=0; u<subdivisions2; ++u) {
      const float
        alpha = (float)(u*2*cimg::PI/subdivisions2),
        beta = (float)(v*2*cimg::PI/subdivisions1),
        x = (float)((0.5f+inner_radius*std::cos(alpha))*std::cos(beta)),
        y = (float)((0.5f+inner_radius*std::cos(alpha))*std::sin(beta)),
        z = (float)(inner_radius*std::sin(alpha));
      points.insert(CImg<>::vector(x,y,z));
    }
  for (unsigned int vv=0; vv<subdivisions1; ++vv)
    for (unsigned int uu=0; uu<subdivisions2; ++uu) {
      const int nv = (vv+1)%subdivisions1, nu = (uu+1)%subdivisions2;
      primitives.insert(CImg<unsigned int>::vector(subdivisions2*vv+nu,subdivisions2*vv+uu,subdivisions2*nv+uu));
      primitives.insert(CImg<unsigned int>::vector(subdivisions2*vv+nu,subdivisions2*nv+uu,subdivisions2*nv+nu));
    }
  return points.get_append('x');
}

//! Get a plane.
template<typename tf> static CImg plane(CImgList<tf>& primitives, const unsigned int sizex=10, const unsigned int sizey=10,
                                        const bool double_sided=true) {
  CImgList<T> points;
  primitives.assign();
  const unsigned int w = sizex+1, h = sizey+1;
  float sizex2 = sizex/2.0f, sizey2 = sizey/2.0f;
  { for (unsigned int y=0; y<h; ++y) for (unsigned int x=0; x<w; x++) points.insert(CImg<T>::vector(x-sizex2,y-sizey2,0)); }
  for (unsigned int y=0; y<sizey; ++y) for (unsigned int x=0; x<sizex; ++x) {
    const int off1 = x+y*w, off2 = x+1+y*w, off3 = x+1+(y+1)*w, off4 = x+(y+1)*w;
    primitives.insert(CImg<tf>::vector(off1,off2,off3,off4));
    if (double_sided) primitives.insert(CImg<tf>::vector(off1,off4,off3,off2));
  }
  return points.get_append('x');
}

//! Get a sphere.
template<typename tf> static CImg sphere(CImgList<tf>& primitives, const unsigned int subdivisions=3) {

  // Create initial icosahedron
  const double tmp = (1+std::sqrt(5.0f))/2.0f, a = 1.0/std::sqrt(1+tmp*tmp), b = tmp*a;
  CImgList<T> points(12,1,3,1,1, b,a,0.0, -b,a,0.0, -b,-a,0.0, b,-a,0.0, a,0.0,b, a,0.0,-b,
                                 -a,0.0,-b, -a,0.0,b, 0.0,b,a, 0.0,-b,a, 0.0,-b,-a, 0.0,b,-a);
  primitives.assign(20,1,3,1,1, 4,8,7, 4,7,9, 5,6,11, 5,10,6, 0,4,3, 0,3,5, 2,7,1, 2,1,6,
                                8,0,11, 8,11,1, 9,10,3, 9,2,10, 8,4,0, 11,0,5, 4,9,3,
                                5,3,10, 7,8,1, 6,1,11, 7,2,9, 6,10,2);

  // Recurse subdivisions
  for (unsigned int i=0; i<subdivisions; ++i) {
    const unsigned int L = primitives.size;
    for (unsigned int l=0; l<L; ++l) {
      const unsigned int
        p0 = (unsigned int)primitives(0,0), p1 = (unsigned int)primitives(0,1), p2 = (unsigned int)primitives(0,2);
      const float
        x0 = (float)points(p0,0), y0 = (float)points(p0,1), z0 = (float)points(p0,2),
        x1 = (float)points(p1,0), y1 = (float)points(p1,1), z1 = (float)points(p1,2),
        x2 = (float)points(p2,0), y2 = (float)points(p2,1), z2 = (float)points(p2,2),
        tnx0 = (x0+x1)/2, tny0 = (y0+y1)/2, tnz0 = (z0+z1)/2, nn0 = (float)std::sqrt(tnx0*tnx0+tny0*tny0+tnz0*tnz0),
        tnx1 = (x0+x2)/2, tny1 = (y0+y2)/2, tnz1 = (z0+z2)/2, nn1 = (float)std::sqrt(tnx1*tnx1+tny1*tny1+tnz1*tnz1),
        tnx2 = (x1+x2)/2, tny2 = (y1+y2)/2, tnz2 = (z1+z2)/2, nn2 = (float)std::sqrt(tnx2*tnx2+tny2*tny2+tnz2*tnz2),
        nx0 = tnx0/nn0, ny0 = tny0/nn0, nz0 = tnz0/nn0,
        nx1 = tnx1/nn1, ny1 = tny1/nn1, nz1 = tnz1/nn1,
        nx2 = tnx2/nn2, ny2 = tny2/nn2, nz2 = tnz2/nn2;
      int i0=-1, i1=-1, i2=-1;
      cimglist_for(points,p) {
        const float x = (float)points(p,0), y = (float)points(p,1), z = (float)points(p,2);
        if (x==nx0 && y==ny0 && z==nz0) i0 = p;
        if (x==nx1 && y==ny1 && z==nz1) i1 = p;
        if (x==nx2 && y==ny2 && z==nz2) i2 = p;
      }
      if (i0<0) { points.insert(CImg<>::vector(nx0,ny0,nz0)); i0 = points.size-1; }
      if (i1<0) { points.insert(CImg<>::vector(nx1,ny1,nz1)); i1 = points.size-1; }
      if (i2<0) { points.insert(CImg<>::vector(nx2,ny2,nz2)); i2 = points.size-1; }
      primitives.remove(0);
      primitives.insert(CImg<unsigned int>::vector(p0,i0,i1)).
        insert(CImg<unsigned int>::vector(i0,p1,i2)).
        insert(CImg<unsigned int>::vector(i1,i2,p2)).
        insert(CImg<unsigned int>::vector(i1,i0,i2));
    }
  }
  return points.get_append('x');
}

//! Get an ellipsoid
template<typename tf, typename t> static CImg ellipsoid(CImgList<tf>& primitives, const CImg<t>& tensor, const unsigned int subdivisions=3) {
  typedef typename cimg::largest<t,float>::type ftype;
  CImg<ftype> S,V;
  tensor.symmetric_eigen(S,V);
  const ftype l0 = S[0], l1 = S[1], l2 = S[2];
  CImg<T> points = sphere(primitives,subdivisions);
  cimg_forX(points,p) { points(p,0) = points(p,0)*l0; points(p,1) = points(p,1)*l1; points(p,2) = points(p,2)*l2; }
  V.transpose();
  points = V*points;
  return points;
}

//! Rescale and optionally center a 3D object.
CImg& resize_object3d(const float siz=100, const bool centering=true) {
  T *ptrx = ptr(0,0), *ptry = ptr(0,1), *ptrz = ptr(0,2);
  float xm = (float)*(ptrx++), ym = (float)*(ptry++), zm = (float)*(ptrz++), xM = xm, yM = ym, zM = zm;
  for (unsigned int p=1; p<width; p++) {
    const float x = (float)*(ptrx++), y = (float)*(ptry++), z = (float)*(ptrz++);
    if (x<xm) xm = x;
    if (y<ym) ym = y;
    if (z<zm) zm = z;
    if (x>xM) xM = x;
    if (y>yM) yM = y;
    if (z>zM) zM = z;
  }
  const float
    cx = 0.5f*(xm+xM),
    cy = 0.5f*(ym+yM),
    cz = 0.5f*(zm+zM),
    delta = cimg::max(xM-xm,yM-ym,zM-zm),
    ratio = (siz>=0)?(delta<=0?0:(siz/delta)):-siz/100;
  ptrx = ptr(0,0);
  ptry = ptr(0,1);
  ptrz = ptr(0,2);
  if (centering) cimg_forX(*this,l) {
    T &x = *(ptrx++), &y = *(ptry++), &z = *(ptrz++);
    x = (T)((x-cx)*ratio);
    y = (T)((y-cy)*ratio);
    z = (T)((z-cz)*ratio);
  } else cimg_forX(*this,l) {
    T &x = *(ptrx++), &y = *(ptry++), &z = *(ptrz++);
    x = (T)(cx+(x-cx)*ratio);
    y = (T)(cy+(y-cy)*ratio);
    z = (T)(cz+(z-cz)*ratio);
  }
  return *this;
}

//! Get a rescaled and centered version of the 3D object
CImg get_resize_object3d(const float siz=100, const bool centering=true) const {
  return CImg<T>(*this,false).resize_object3d(siz,centering);
}

//! Insert a 3D object into another one
template<typename tf, typename tp, typename tff>
  CImg& insert_object3d(CImgList<tf>& primitives, const CImg<tp>& obj_points, const CImgList<tff>& obj_primitives,
                        const float posx=0, const float posy=0, const float posz=0) {
  const unsigned int P = width;
  append(obj_points,'x');
  for (unsigned int l=P; l<width; ++l) { (*this)(l,0)+=posx; (*this)(l,1)+=posy; (*this)(l,2)+=posz; }
  const unsigned int N = primitives.size;
  primitives.insert(obj_primitives);
  for (unsigned int i=N; i<primitives.size; ++i) {
    CImg<tf> &p = primitives[i];
    if (p.size()!=5) p+=P;
    else { p[0]+=P; if (p[2]==0) p[1]+=P; }
  }
  return *this;
}

//-----------------------------------------------------------------------
// The functions defined below use the 'Board' Library
// ( http://www.greyc.ensicaen.fr/~seb/board/ )
//------------------------------------------------------------------------
#ifdef cimg_use_board

//! Draw a 3D object in the instance image, and make a vector copy in a Board instance.
/**
   This function is a simple overload of the core library function CImg<T>::draw_object3d(),
   where a 'Board' object is specified in the first argument.
   What it does is drawing the 3D object both in the image and in the board.
   The board can be save then in vector-graphics format, such as EPS, SVG or FIG.

   Example of code :
   \code
   CImg<unsigned char> img(100,100,1,3);   // Define a 100x100 color image
   Board B;
   B.clear();
   img.draw_object3d(B,points,faces,colors,,...);  // Draw object 3d both in board and image 'img'.
   B.saveSVG("output.svg");     // Save as a vector-graphics file format.
   \endcode
**/
template<typename tp, typename tf, typename to>
  CImg& draw_object3d(BoardLib::Board& board, const float X, const float Y, const float Z,
                      const CImg<tp>& points, const CImgList<tf>& primitives,
                      const CImgList<T>& colors, const CImgList<to>& opacities,
                      const unsigned int render_type=4,
                      const bool double_sided=false, const float focale=500,
                      const float lightx=0, const float lighty=0, const float lightz=-5000,
                      const float ambient_light=0.05f) {

  static CImg<float> light_texture;
  if (is_empty() || !points || !primitives) return *this;
  if (!colors || !opacities)
    throw CImgArgumentException("CImg<%s>::draw_object3d() : Undefined colors or opacities",pixel_type());

  if (points.height<3)
    return draw_object3d(board,X,Y,Z,points.get_resize(-100,3,1,1,0),primitives,colors,opacities,
                         render_type,double_sided,focale,lightx,lighty,lightz,ambient_light);

  // Create light texture for phong-like rendering
  if (render_type==5) {
    if (colors.size>primitives.size) light_texture.assign(colors[primitives.size])/=255;
    else {
      static float olightx=0, olighty=0, olightz=0, oambient_light=0;
      if (!light_texture || lightx!=olightx || lighty!=olighty || lightz!=olightz || ambient_light!=oambient_light) {
        light_texture.assign(512,512);
        const float white[] = { 1.0f },
          dlx = lightx-X, dly = lighty-Y, dlz = lightz-Z,
            nl = (float)std::sqrt(dlx*dlx+dly*dly+dlz*dlz),
            nlx = light_texture.width/2*(1+dlx/nl),
            nly = light_texture.height/2*(1+dly/nl);
          (light_texture.draw_gaussian(nlx,nly,light_texture.width/3.0f,white)+=ambient_light);
          olightx = lightx; olighty = lighty; olightz = lightz; oambient_light = ambient_light;
      }
    }
  }

  // Compute 3D to 2D projection
  CImg<float> projections(points.width,2);
  cimg_forX(points,l) {
    const float
      x = (float)points(l,0),
      y = (float)points(l,1),
      z = (float)points(l,2);
    const float projectedz = z + Z + focale;
    projections(l,1) = Y + focale*y/projectedz;
    projections(l,0) = X + focale*x/projectedz;
  }

  // Compute and sort visible primitives
  CImg<unsigned int> visibles(primitives.size);
  CImg<float> zrange(primitives.size);
  unsigned int nb_visibles = 0;
  const float zmin = -focale+1.5f;
  { cimglist_for(primitives,l) {
    const CImg<tf>& primitive = primitives[l];
    switch (primitive.size()) {
    case 1: { // Point
      const unsigned int i0 = (unsigned int)primitive(0);
      const float x0 = projections(i0,0), y0 = projections(i0,1), z0 = (float)(Z+points(i0,2));
      if (z0>zmin && x0>=0 && x0<width && y0>=0 && y0<height) {
        visibles(nb_visibles) = (unsigned int)l;
        zrange(nb_visibles++) = z0;
      }
    } break;
    case 5: { // Sphere
      const unsigned int
        i0 = (unsigned int)primitive(0),
        i1 = (unsigned int)primitive(1),
        i2 = (unsigned int)primitive(2);
      const float x0 = projections(i0,0), y0 = projections(i0,1), z0 = (float)(Z+points(i0,2));
      int radius;
      if (i2) radius = (int)(i2*focale/(z0+focale));
      else {
        const float x1 = projections(i1,0), y1 = projections(i1,1);
        const int deltax = (int)(x1-x0), deltay = (int)(y1-y0);
        radius = (int)std::sqrt(deltax*deltax + deltay*deltay);
      }
      if (z0>zmin && x0+radius>=0 && x0-radius<width && y0+radius>=0 && y0-radius<height) {
        visibles(nb_visibles) = (unsigned int)l;
        zrange(nb_visibles++) = z0;
      }
    } break;
    case 2: // Line or textured line
    case 6: {
      const unsigned int
        i0 = (unsigned int)primitive(0),
        i1 = (unsigned int)primitive(1);
      const float
        x0 = projections(i0,0), y0 = projections(i0,1), z0 = (float)(Z+points(i0,2)),
        x1 = projections(i1,0), y1 = projections(i1,1), z1 = (float)(Z+points(i1,2));
      float xm, xM, ym, yM;
      if (x0<x1) { xm = x0; xM = x1; } else { xm = x1; xM = x0; }
      if (y0<y1) { ym = y0; yM = y1; } else { ym = y1; yM = y0; }
      if (z0>zmin && z1>zmin && xM>=0 && xm<width && yM>=0 && ym<height) {
        visibles(nb_visibles) = (unsigned int)l;
        zrange(nb_visibles++) = 0.5f*(z0+z1);
      }
    } break;
    case 3:  // Triangle or textured triangle
    case 9: {
      const unsigned int
        i0 = (unsigned int)primitive(0),
        i1 = (unsigned int)primitive(1),
        i2 = (unsigned int)primitive(2);
      const float
        x0 = projections(i0,0), y0 = projections(i0,1), z0 = (float)(Z+points(i0,2)),
        x1 = projections(i1,0), y1 = projections(i1,1), z1 = (float)(Z+points(i1,2)),
        x2 = projections(i2,0), y2 = projections(i2,1), z2 = (float)(Z+points(i2,2));
      float xm, xM, ym, yM;
      if (x0<x1) { xm = x0; xM = x1; } else { xm = x1; xM = x0; }
      if (x2<xm) xm = x2;
      if (x2>xM) xM = x2;
      if (y0<y1) { ym = y0; yM = y1; } else { ym = y1; yM = y0; }
      if (y2<ym) ym = y2;
      if (y2>yM) yM = y2;
      if (z0>zmin && z1>zmin && z2>zmin && xM>=0 && xm<width && yM>=0 && ym<height) {
        const float d = (x1-x0)*(y2-y0)-(x2-x0)*(y1-y0);
        if (double_sided || d<0) {
          visibles(nb_visibles) = (unsigned int)l;
          zrange(nb_visibles++) = (z0+z1+z2)/3;
        }
      }
    } break;
    case 4: // Rectangle or textured rectangle
    case 12: {
      const unsigned int
        i0 = (unsigned int)primitive(0),
        i1 = (unsigned int)primitive(1),
        i2 = (unsigned int)primitive(2),
        i3 = (unsigned int)primitive(3);
      const float
        x0 = projections(i0,0), y0 = projections(i0,1), z0 = (float)(Z+points(i0,2)),
        x1 = projections(i1,0), y1 = projections(i1,1), z1 = (float)(Z+points(i1,2)),
        x2 = projections(i2,0), y2 = projections(i2,1), z2 = (float)(Z+points(i2,2)),
        x3 = projections(i3,0), y3 = projections(i3,1), z3 = (float)(Z+points(i3,2));
      float xm, xM, ym, yM;
      if (x0<x1) { xm = x0; xM = x1; } else { xm = x1; xM = x0; }
      if (x2<xm) xm = x2;
      if (x2>xM) xM = x2;
      if (x3<xm) xm = x3;
      if (x3>xM) xM = x3;
      if (y0<y1) { ym = y0; yM = y1; } else { ym = y1; yM = y0; }
      if (y2<ym) ym = y2;
      if (y2>yM) yM = y2;
      if (y3<ym) ym = y3;
      if (y3>yM) yM = y3;
      if (z0>zmin && z1>zmin && z2>zmin && z3>zmin && xM>=0 && xm<width && yM>=0 && ym<height) {
        const float d = (x1-x0)*(y2-y0)-(x2-x0)*(y1-y0);
        if (double_sided || d<0) {
          visibles(nb_visibles) = (unsigned int)l;
          zrange(nb_visibles++) = (z0+z1+z2+z3)/4;
        }
      }
    } break;
    default:
      throw CImgArgumentException("CImg<%s>::draw_object3d() : Primitive %u is invalid (size = %u, can be 1,2,3,4,5,6,9 or 12)",
                                  pixel_type(),l,primitive.size());
    }}
  }
  if (nb_visibles<=0) return *this;
  CImg<unsigned int> permutations;
  CImg<float>(zrange.data,nb_visibles,1,1,1,true).sort(permutations,false);

  // Compute light properties
  CImg<float> lightprops;
  switch (render_type) {
  case 3: { // Flat Shading
    lightprops.assign(nb_visibles);
    cimg_forX(lightprops,l) {
      const CImg<tf>& primitive = primitives(visibles(permutations(l)));
      const unsigned int psize = primitive.size();
      if (psize==3 || psize==4 || psize==9 || psize==12) {
        const unsigned int
          i0 = (unsigned int)primitive(0),
          i1 = (unsigned int)primitive(1),
          i2 = (unsigned int)primitive(2);
        const float
          x0 = (float)points(i0,0), y0 = (float)points(i0,1), z0 = (float)points(i0,2),
          x1 = (float)points(i1,0), y1 = (float)points(i1,1), z1 = (float)points(i1,2),
          x2 = (float)points(i2,0), y2 = (float)points(i2,1), z2 = (float)points(i2,2),
          dx1 = x1-x0, dy1 = y1-y0, dz1 = z1-z0,
          dx2 = x2-x0, dy2 = y2-y0, dz2 = z2-z0,
          nx = dy1*dz2-dz1*dy2,
          ny = dz1*dx2-dx1*dz2,
          nz = dx1*dy2-dy1*dx2,
          norm = (float)std::sqrt(1e-5f+nx*nx+ny*ny+nz*nz),
          lx = X+(x0+x1+x2)/3-lightx,
          ly = Y+(y0+y1+y2)/3-lighty,
          lz = Z+(z0+z1+z2)/3-lightz,
          nl = (float)std::sqrt(1e-5f+lx*lx+ly*ly+lz*lz),
          factor = cimg::abs(-lx*nx-ly*ny-lz*nz)/(norm*nl);
        lightprops[l] = cimg::max(factor,0.0f) + ambient_light;
      } else lightprops[l] = 1.0f;
    }
  } break;

  case 4: // Gouraud Shading
  case 5: { // Phong-Shading
    CImg<float> points_normals(points.width,double_sided?7:3,1,1,0);
    for (unsigned int l=0; l<nb_visibles; ++l) {
      const CImg<tf>& primitive = primitives[visibles(l)];
      const unsigned int psize = primitive.size();
      const bool
        triangle_flag  = (psize==3) || (psize==9),
        rectangle_flag = (psize==4) || (psize==12);
      if (triangle_flag || rectangle_flag) {
        const unsigned int
          i0 = (unsigned int)primitive(0),
          i1 = (unsigned int)primitive(1),
          i2 = (unsigned int)primitive(2),
          i3 = rectangle_flag?(unsigned int)primitive(3):0;
        const float
          x0 = (float)points(i0,0), y0 = (float)points(i0,1), z0 = (float)points(i0,2),
          x1 = (float)points(i1,0), y1 = (float)points(i1,1), z1 = (float)points(i1,2),
          x2 = (float)points(i2,0), y2 = (float)points(i2,1), z2 = (float)points(i2,2),
          dx1 = x1-x0, dy1 = y1-y0, dz1 = z1-z0,
          dx2 = x2-x0, dy2 = y2-y0, dz2 = z2-z0,
          nnx = dy1*dz2-dz1*dy2,
          nny = dz1*dx2-dx1*dz2,
          nnz = dx1*dy2-dy1*dx2,
          norm = 1e-5f + (float)std::sqrt(nnx*nnx+nny*nny+nnz*nnz),
          nx = nnx/norm,
          ny = nny/norm,
          nz = nnz/norm;
        if (double_sided) {
          unsigned int ind = nz>0?3U:0U;
          const float incr = nz>0?-1.0f:1.0f;
          points_normals(i0,  ind)+=nx; points_normals(i1,ind)+=nx; points_normals(i2,ind)+=nx;
          points_normals(i0,++ind)+=ny; points_normals(i1,ind)+=ny; points_normals(i2,ind)+=ny;
          points_normals(i0,++ind)+=nz; points_normals(i1,ind)+=nz; points_normals(i2,ind)+=nz;
          points_normals(i0,6)+=incr; points_normals(i1,6)+=incr; points_normals(i2,6)+=incr;
          if (rectangle_flag) {
            points_normals(i3,ind)+=nz; points_normals(i3,--ind)+=ny; points_normals(i3,--ind)+=nz; points_normals(i3,6)+=incr;
          }
        } else {
          points_normals(i0,0)+=nx; points_normals(i0,1)+=ny; points_normals(i0,2)+=nz;
          points_normals(i1,0)+=nx; points_normals(i1,1)+=ny; points_normals(i1,2)+=nz;
          points_normals(i2,0)+=nx; points_normals(i2,1)+=ny; points_normals(i2,2)+=nz;
          if (rectangle_flag) { points_normals(i3,0)+=nx; points_normals(i3,1)+=ny; points_normals(i3,2)+=nz; }
        }
      }
    }

    if (double_sided) cimg_forX(points_normals,l) if (points_normals(l,6)<0) {
      points_normals(l,0) = -points_normals(l,3);
      points_normals(l,1) = -points_normals(l,4);
      points_normals(l,2) = -points_normals(l,5);
    }

    if (render_type==4) {
      lightprops.assign(points.width);
      cimg_forX(points,ll) {
        const float
          nx = points_normals(ll,0),
          ny = points_normals(ll,1),
          nz = points_normals(ll,2),
          norm = (float)std::sqrt(1e-5f+nx*nx+ny*ny+nz*nz),
          lx = (float)(X+points(ll,0)-lightx),
          ly = (float)(Y+points(ll,1)-lighty),
          lz = (float)(Z+points(ll,2)-lightz),
          nl = (float)std::sqrt(1e-5f+lx*lx+ly*ly+lz*lz),
          factor = (-lx*nx-ly*ny-lz*nz)/(norm*nl);
        lightprops[ll] = cimg::max(factor,0.0f) + ambient_light;
      }
    } else {
      const unsigned int
        lw2 = light_texture.width/2-1,
        lh2 = light_texture.height/2-1;
      lightprops.assign(points.width,2);
      cimg_forX(points,ll) {
        const float
          nx = points_normals(ll,0),
          ny = points_normals(ll,1),
          nz = points_normals(ll,2),
          norm = (float)std::sqrt(1e-5f+nx*nx+ny*ny+nz*nz),
          nnx = nx/norm,
          nny = ny/norm;
        lightprops(ll,0) = lw2*(1+nnx);
        lightprops(ll,1) = lh2*(1+nny);
      }
    }
  } break;
  }

  // Draw visible primitives
  const unsigned int opacsize = opacities.size;
  { for (unsigned int l=0; l<nb_visibles; ++l) {
    const unsigned int n_primitive = visibles(permutations(l));
    const CImg<tf>& primitive = primitives[n_primitive];
    const CImg<T>& color = colors[n_primitive%colors.size];
    const CImg<to>& opacity = opacities[n_primitive%opacsize];
    const float opac = opacity.size()?(float)opacity(0):1.0f;

    switch (primitive.size()) {
    case 1: { // colored point or sprite
      const unsigned int n0 = (unsigned int)primitive[0];
      const int
        x0 = (int)projections(n0,0), y0 = (int)projections(n0,1);
      const float
        fx0 = projections(n0,0), fy0 = projections(n0,1);
      if (color.size()==dim) {
        draw_point(x0,y0,color.ptr(),opac);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.fillCircle(fx0,dimy()-fy0,0);
      }
      else {
        const float z = Z + points(n0,2);
        const int
          factor = (int)(focale*100/(z+focale)),
          sw = color.width*factor/200,
          sh = color.height*factor/200;
        if (x0+sw>=0 && x0-sw<(int)width && y0+sh>=0 && y0-sh<(int)height) {
          const CImg<T> sprite = color.get_resize(-factor,-factor,1,-100,render_type<=3?1:3);
          if (opacity.width==color.width && opacity.height==color.height) {
            draw_image(sprite,opacity.get_resize(sprite.width,sprite.height,1,sprite.dim,1),x0-sw,y0-sh,0,0);
            board.setPenColorRGBi(128,128,128);
            board.setFillColor(BoardLib::Color::none);
            board.drawRectangle(fx0-sw,dimy()-(fy0-sh),sw,sh);
          } else {
            draw_image(sprite,x0-sw,y0-sh,0,0,opac);
            board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
            board.setFillColor(BoardLib::Color::none);
            board.drawRectangle(fx0-sw,dimy()-(fy0-sh),sw,sh);
          }
        }
      }
    } break;
    case 2: { // colored line
      const unsigned int
        n0 = (unsigned int)primitive[0],
        n1 = (unsigned int)primitive[1];
      const int
        x0 = (int)projections(n0,0), y0 = (int)projections(n0,1),
        x1 = (int)projections(n1,0), y1 = (int)projections(n1,1);
      const float
        fx0 = projections(n0,0), fy0 = projections(n0,1),
        fx1 = projections(n1,0), fy1 = projections(n1,1);
      if (render_type) {
        draw_line(x0,y0,x1,y1,color.ptr(),opac);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.drawLine(fx0,dimy()-fy0,x1,dimy()-fy1);
      } else {
        draw_point(x0,y0,color.ptr(),opac).draw_point(x1,y1,color.ptr(),opac);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.drawCircle(fx0,dimy()-fy0,0);
        board.drawCircle(fx1,dimy()-fy1,0);
      }
    } break;
    case 5: { // colored sphere
      const unsigned int
        n0 = (unsigned int)primitive[0],
        n1 = (unsigned int)primitive[1],
        n2 = (unsigned int)primitive[2];
      const int
        x0 = (int)projections(n0,0), y0 = (int)projections(n0,1);
      const float
        fx0 = projections(n0,0), fy0 = projections(n0,1);
      int radius;
      float fradius;
      if (n2) radius = (int)(fradius=n2*focale/(Z+points(n0,2)+focale));
      else {
        const int
          x1 = (int)projections(n1,0), y1 = (int)projections(n1,1),
          deltax = x1-x0, deltay = y1-y0;
        radius = (int)(fradius=std::sqrt(deltax*deltax + deltay*deltay));
      }
      switch (render_type) {
      case 0:
        draw_point(x0,y0,color.ptr(),opac);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.fillCircle(fx0,dimy()-fy0,0);
        break;
      case 1:
        draw_circle(x0,y0,radius,color.ptr(),opac,~0U);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.setFillColor(BoardLib::Color::none);
        board.drawCircle(fx0,dimy()-fy0,fradius);
        break;
      default:
        draw_circle(x0,y0,radius,color.ptr(),opac);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.fillCircle(fx0,dimy()-fy0,fradius);
        break;
      }
    } break;
    case 6: { // textured line
      const unsigned int
        n0 = (unsigned int)primitive[0],
        n1 = (unsigned int)primitive[1],
        tx0 = (unsigned int)primitive[2],
        ty0 = (unsigned int)primitive[3],
        tx1 = (unsigned int)primitive[4],
        ty1 = (unsigned int)primitive[5];
      const int
        x0 = (int)projections(n0,0), y0 = (int)projections(n0,1),
        x1 = (int)projections(n1,0), y1 = (int)projections(n1,1);
      const float
        fx0 = projections(n0,0), fy0 = projections(n0,1),
        fx1 = projections(n1,0), fy1 = projections(n1,1);
      if (render_type) {
        draw_line(x0,y0,x1,y1,color,tx0,ty0,tx1,ty1,opac);
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.drawLine(fx0,dimy()-fy0,fx1,dimy()-fy1);
      } else {
        draw_point(x0,y0,color.get_vector_at(tx0,ty0).ptr(),opac).
          draw_point(x1,y1,color.get_vector_at(tx1,ty1).ptr(),opac);
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.drawCircle(fx0,dimy()-fy0,0);
        board.drawCircle(fx1,dimy()-fy1,0);
      }
    } break;
    case 3: { // colored triangle
      const unsigned int
        n0 = (unsigned int)primitive[0],
        n1 = (unsigned int)primitive[1],
        n2 = (unsigned int)primitive[2];
      const int
        x0 = (int)projections(n0,0), y0 = (int)projections(n0,1),
        x1 = (int)projections(n1,0), y1 = (int)projections(n1,1),
        x2 = (int)projections(n2,0), y2 = (int)projections(n2,1);
      const float
        fx0 = projections(n0,0), fy0 = projections(n0,1),
        fx1 = projections(n1,0), fy1 = projections(n1,1),
        fx2 = projections(n2,0), fy2 = projections(n2,1);
      switch(render_type) {
      case 0: {
        draw_point(x0,y0,color.ptr(),opac).draw_point(x1,y1,color.ptr(),opac).draw_point(x2,y2,color.ptr(),opac);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.drawCircle(fx0,dimy()-fy0,0);
        board.drawCircle(fx1,dimy()-fy1,0);
        board.drawCircle(fx2,dimy()-fy2,0);
      } break;
      case 1: {
        draw_line(x0,y0,x1,y1,color.ptr(),opac).draw_line(x0,y0,x2,y2,color.ptr(),opac).
          draw_line(x1,y1,x2,y2,color.ptr(),opac);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.drawLine(fx0,dimy()-fy0,fx1,dimy()-fy1);
        board.drawLine(fx0,dimy()-fy0,fx2,dimy()-fy2);
        board.drawLine(fx1,dimy()-fy1,fx2,dimy()-fy2);
        } break;
      case 2: {
        draw_triangle(x0,y0,x1,y1,x2,y2,color.ptr(),opac);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.fillTriangle(fx0,dimy()-fy0,fx1,dimy()-fy1,fx2,dimy()-fy2);
      } break;
      case 3: {
        _draw_triangle(x0,y0,x1,y1,x2,y2,color.ptr(),opac,lightprops(l));
        const float lp = cimg::min(lightprops(l),1.0f);
        board.setPenColorRGBi((unsigned char)(color[0]*lp),
                              (unsigned char)(color[1]*lp),
                              (unsigned char)(color[2]*lp),
                              (unsigned char)(opac*255));
        board.fillTriangle(fx0,dimy()-fy0,fx1,dimy()-fy1,fx2,dimy()-fy2);
      } break;
      case 4: {
        draw_triangle(x0,y0,x1,y1,x2,y2,color.ptr(),lightprops(n0),lightprops(n1),lightprops(n2),opac);
        board.setPenColorRGBi((unsigned char)(color[0]),
                              (unsigned char)(color[1]),
                              (unsigned char)(color[2]),
                              (unsigned char)(opac*255));
        board.fillGouraudTriangle(fx0,dimy()-fy0,lightprops(n0),
                                  fx1,dimy()-fy1,lightprops(n1),
                                  fx2,dimy()-fy2,lightprops(n2));
      } break;
      case 5: {
        draw_triangle(x0,y0,x1,y1,x2,y2,color.ptr(),light_texture,
                      (unsigned int)lightprops(n0,0), (unsigned int)lightprops(n0,1),
                      (unsigned int)lightprops(n1,0), (unsigned int)lightprops(n1,1),
                      (unsigned int)lightprops(n2,0), (unsigned int)lightprops(n2,1),
                      opac);
        const float
          l0 = light_texture((int)(light_texture.dimx()/2*(1+lightprops(n0,0))), (int)(light_texture.dimy()/2*(1+lightprops(n0,1)))),
          l1 = light_texture((int)(light_texture.dimx()/2*(1+lightprops(n1,0))), (int)(light_texture.dimy()/2*(1+lightprops(n1,1)))),
          l2 = light_texture((int)(light_texture.dimx()/2*(1+lightprops(n2,0))), (int)(light_texture.dimy()/2*(1+lightprops(n2,1))));
        board.setPenColorRGBi((unsigned char)(color[0]),
                              (unsigned char)(color[1]),
                              (unsigned char)(color[2]),
                              (unsigned char)(opac*255));
        board.fillGouraudTriangle(fx0,dimy()-fy0,l0,
                                  fx1,dimy()-fy1,l1,
                                  fx2,dimy()-fy2,l2);
      } break;
      }
    } break;
    case 4: { // colored rectangle
      const unsigned int
        n0 = (unsigned int)primitive[0],
        n1 = (unsigned int)primitive[1],
        n2 = (unsigned int)primitive[2],
        n3 = (unsigned int)primitive[3];
      const int
        x0 = (int)projections(n0,0), y0 = (int)projections(n0,1),
        x1 = (int)projections(n1,0), y1 = (int)projections(n1,1),
        x2 = (int)projections(n2,0), y2 = (int)projections(n2,1),
        x3 = (int)projections(n3,0), y3 = (int)projections(n3,1);
      const float
        fx0 = projections(n0,0), fy0 = projections(n0,1),
        fx1 = projections(n1,0), fy1 = projections(n1,1),
        fx2 = projections(n2,0), fy2 = projections(n2,1),
        fx3 = projections(n3,0), fy3 = projections(n3,1);
      switch(render_type) {
      case 0: {
        draw_point(x0,y0,color.ptr(),opac).draw_point(x1,y1,color.ptr(),opac).
          draw_point(x2,y2,color.ptr(),opac).draw_point(x3,y3,color.ptr(),opac);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.drawCircle(fx0,dimy()-fy0,0);
        board.drawCircle(fx1,dimy()-fy1,0);
        board.drawCircle(fx2,dimy()-fy2,0);
        board.drawCircle(fx3,dimy()-fy3,0);
      } break;
      case 1: {
        draw_line(x0,y0,x1,y1,color.ptr(),opac).draw_line(x1,y1,x2,y2,color.ptr(),opac).
          draw_line(x2,y2,x3,y3,color.ptr(),opac).draw_line(x3,y3,x0,y0,color.ptr(),opac);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.drawLine(fx0,dimy()-fy0,fx1,dimy()-fy1);
        board.drawLine(fx1,dimy()-fy1,fx2,dimy()-fy2);
        board.drawLine(fx2,dimy()-fy2,fx3,dimy()-fy3);
        board.drawLine(fx3,dimy()-fy3,fx0,dimy()-fy0);
      } break;
      case 2: {
        draw_triangle(x0,y0,x1,y1,x2,y2,color.ptr(),opac).draw_triangle(x0,y0,x2,y2,x3,y3,color.ptr(),opac);
        board.setPenColorRGBi(color[0],color[1],color[2],(unsigned char)(opac*255));
        board.fillTriangle(fx0,dimy()-fy0,fx1,dimy()-fy1,fx2,dimy()-fy2);
        board.fillTriangle(fx0,dimy()-fy0,fx2,dimy()-fy2,fx3,dimy()-fy3);
      } break;
      case 3: {
        _draw_triangle(x0,y0,x1,y1,x2,y2,color.ptr(),opac,lightprops(l)).
          _draw_triangle(x0,y0,x2,y2,x3,y3,color.ptr(),opac,lightprops(l));
        const float lp = cimg::min(lightprops(l),1.0f);
        board.setPenColorRGBi((unsigned char)(color[0]*lp),
                              (unsigned char)(color[1]*lp),
                              (unsigned char)(color[2]*lp),(unsigned char)(opac*255));
        board.fillTriangle(fx0,dimy()-fy0,fx1,dimy()-fy1,fx2,dimy()-fy2);
        board.fillTriangle(fx0,dimy()-fy0,fx2,dimy()-fy2,fx3,dimy()-fy3);
      } break;
      case 4: {
        const float
          lightprop0 = lightprops(n0), lightprop1 = lightprops(n1),
          lightprop2 = lightprops(n2), lightprop3 = lightprops(n3);
        draw_triangle(x0,y0,x1,y1,x2,y2,color.ptr(),lightprop0,lightprop1,lightprop2,opac).
          draw_triangle(x0,y0,x2,y2,x3,y3,color.ptr(),lightprop0,lightprop2,lightprop3,opac);
        board.setPenColorRGBi((unsigned char)(color[0]),
                              (unsigned char)(color[1]),
                              (unsigned char)(color[2]),
                              (unsigned char)(opac*255));
        board.fillGouraudTriangle(fx0,dimy()-fy0,lightprop0,
                                  fx1,dimy()-fy1,lightprop1,
                                  fx2,dimy()-fy2,lightprop2);
        board.fillGouraudTriangle(fx0,dimy()-fy0,lightprop0,
                                  fx2,dimy()-fy2,lightprop2,
                                  fx3,dimy()-fy3,lightprop3);
      } break;
      case 5: {
        const unsigned int
          lx0 = (unsigned int)lightprops(n0,0), ly0 = (unsigned int)lightprops(n0,1),
          lx1 = (unsigned int)lightprops(n1,0), ly1 = (unsigned int)lightprops(n1,1),
          lx2 = (unsigned int)lightprops(n2,0), ly2 = (unsigned int)lightprops(n2,1),
          lx3 = (unsigned int)lightprops(n3,0), ly3 = (unsigned int)lightprops(n3,1);
        draw_triangle(x0,y0,x1,y1,x2,y2,color.ptr(),light_texture,lx0,ly0,lx1,ly1,lx2,ly2,opac).
          draw_triangle(x0,y0,x2,y2,x3,y3,color.ptr(),light_texture,lx0,ly0,lx2,ly2,lx3,ly3,opac);

        const float
          l0 = light_texture((int)(light_texture.dimx()/2*(1+lx0)), (int)(light_texture.dimy()/2*(1+ly0))),
          l1 = light_texture((int)(light_texture.dimx()/2*(1+lx1)), (int)(light_texture.dimy()/2*(1+ly1))),
          l2 = light_texture((int)(light_texture.dimx()/2*(1+lx2)), (int)(light_texture.dimy()/2*(1+ly2))),
          l3 = light_texture((int)(light_texture.dimx()/2*(1+lx3)), (int)(light_texture.dimy()/2*(1+ly3)));
        board.setPenColorRGBi((unsigned char)(color[0]),
                              (unsigned char)(color[1]),
                              (unsigned char)(color[2]),
                              (unsigned char)(opac*255));
        board.fillGouraudTriangle(fx0,dimy()-fy0,l0,
                                  fx1,dimy()-fy1,l1,
                                  fx2,dimy()-fy2,l2);
        board.fillGouraudTriangle(fx0,dimy()-fy0,l0,
                                  fx2,dimy()-fy2,l2,
                                  fx3,dimy()-fy3,l3);
      } break;
      }
    } break;
    case 9: { // Textured triangle
      const unsigned int
        n0 = (unsigned int)primitive[0],
        n1 = (unsigned int)primitive[1],
        n2 = (unsigned int)primitive[2],
        tx0 = (unsigned int)primitive[3],
        ty0 = (unsigned int)primitive[4],
        tx1 = (unsigned int)primitive[5],
        ty1 = (unsigned int)primitive[6],
        tx2 = (unsigned int)primitive[7],
        ty2 = (unsigned int)primitive[8];
      const int
        x0 = (int)projections(n0,0), y0 = (int)projections(n0,1),
        x1 = (int)projections(n1,0), y1 = (int)projections(n1,1),
        x2 = (int)projections(n2,0), y2 = (int)projections(n2,1);
      const float
        fx0 = projections(n0,0), fy0 = projections(n0,1),
        fx1 = projections(n1,0), fy1 = projections(n1,1),
        fx2 = projections(n2,0), fy2 = projections(n2,1);
      switch(render_type) {
      case 0: {
        draw_point(x0,y0,color.get_vector_at(tx0,ty0).ptr(),opac).
          draw_point(x1,y1,color.get_vector_at(tx1,ty1).ptr(),opac).
          draw_point(x2,y2,color.get_vector_at(tx2,ty2).ptr(),opac);
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.drawCircle(fx0,dimy()-fy0,0);
        board.drawCircle(fx1,dimy()-fy1,0);
        board.drawCircle(fx2,dimy()-fy2,0);
      } break;
      case 1: {
        draw_line(x0,y0,x1,y1,color,tx0,ty0,tx1,ty1,opac).
          draw_line(x0,y0,x2,y2,color,tx0,ty0,tx2,ty2,opac).
          draw_line(x1,y1,x2,y2,color,tx1,ty1,tx2,ty2,opac);
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.drawLine(fx0,dimy()-fy0,fx1,dimy()-fy1);
        board.drawLine(fx0,dimy()-fy0,fx2,dimy()-fy2);
        board.drawLine(fx1,dimy()-fy1,fx2,dimy()-fy2);
      } break;
      case 2: {
        draw_triangle(x0,y0,x1,y1,x2,y2,color,tx0,ty0,tx1,ty1,tx2,ty2,opac);
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.fillTriangle(fx0,dimy()-fy0,fx1,dimy()-fy1,fx2,dimy()-fy2);
      } break;
      case 3: {
        draw_triangle(x0,y0,x1,y1,x2,y2,color,tx0,ty0,tx1,ty1,tx2,ty2,opac,lightprops(l));
        const float lp = cimg::min(lightprops(l),1.0f);
        board.setPenColorRGBi((unsigned char)(128*lp),
                              (unsigned char)(128*lp),
                              (unsigned char)(128*lp),
                              (unsigned char)(opac*255));
        board.fillTriangle(fx0,dimy()-fy0,fx1,dimy()-fy1,fx2,dimy()-fy2);
      } break;
      case 4: {
        draw_triangle(x0,y0,x1,y1,x2,y2,color,tx0,ty0,tx1,ty1,tx2,ty2,lightprops(n0),lightprops(n1),lightprops(n2),opac);
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.fillGouraudTriangle(fx0,dimy()-fy0,lightprops(n0),
                                  fx1,dimy()-fy1,lightprops(n1),
                                  fx2,dimy()-fy2,lightprops(n2));
      } break;
      case 5: {
        draw_triangle(x0,y0,x1,y1,x2,y2,color,tx0,ty0,tx1,ty1,tx2,ty2,light_texture,
                      (unsigned int)lightprops(n0,0), (unsigned int)lightprops(n0,1),
                      (unsigned int)lightprops(n1,0), (unsigned int)lightprops(n1,1),
                      (unsigned int)lightprops(n2,0), (unsigned int)lightprops(n2,1),
                      opac);
        const float
          l0 = light_texture((int)(light_texture.dimx()/2*(1+lightprops(n0,0))), (int)(light_texture.dimy()/2*(1+lightprops(n0,1)))),
          l1 = light_texture((int)(light_texture.dimx()/2*(1+lightprops(n1,0))), (int)(light_texture.dimy()/2*(1+lightprops(n1,1)))),
          l2 = light_texture((int)(light_texture.dimx()/2*(1+lightprops(n2,0))), (int)(light_texture.dimy()/2*(1+lightprops(n2,1))));
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.fillGouraudTriangle(fx0,dimy()-fy0,l0,
                                  fx1,dimy()-fy1,l1,
                                  fx2,dimy()-fy2,l2);
      } break;
      }
    } break;
    case 12: { // Textured rectangle
      const unsigned int
        n0 = (unsigned int)primitive[0],
        n1 = (unsigned int)primitive[1],
        n2 = (unsigned int)primitive[2],
        n3 = (unsigned int)primitive[3],
        tx0 = (unsigned int)primitive[4],
        ty0 = (unsigned int)primitive[5],
        tx1 = (unsigned int)primitive[6],
        ty1 = (unsigned int)primitive[7],
        tx2 = (unsigned int)primitive[8],
        ty2 = (unsigned int)primitive[9],
        tx3 = (unsigned int)primitive[10],
        ty3 = (unsigned int)primitive[11];
      const int
        x0 = (int)projections(n0,0), y0 = (int)projections(n0,1),
        x1 = (int)projections(n1,0), y1 = (int)projections(n1,1),
        x2 = (int)projections(n2,0), y2 = (int)projections(n2,1),
        x3 = (int)projections(n3,0), y3 = (int)projections(n3,1);
      const float
        fx0 = projections(n0,0), fy0 = projections(n0,1),
        fx1 = projections(n1,0), fy1 = projections(n1,1),
        fx2 = projections(n2,0), fy2 = projections(n2,1),
        fx3 = projections(n3,0), fy3 = projections(n3,1);
      switch(render_type) {
      case 0: {
        draw_point(x0,y0,color.get_vector_at(tx0,ty0).ptr(),opac).
          draw_point(x1,y1,color.get_vector_at(tx1,ty1).ptr(),opac).
          draw_point(x2,y2,color.get_vector_at(tx2,ty2).ptr(),opac).
          draw_point(x3,y3,color.get_vector_at(tx3,ty3).ptr(),opac);
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.drawCircle(fx0,dimy()-fy0,0);
        board.drawCircle(fx1,dimy()-fy1,0);
        board.drawCircle(fx2,dimy()-fy2,0);
        board.drawCircle(fx3,dimy()-fy3,0);
      } break;
      case 1: {
        draw_line(x0,y0,x1,y1,color,tx0,ty0,tx1,ty1,opac).
          draw_line(x1,y1,x2,y2,color,tx1,ty1,tx2,ty2,opac).
          draw_line(x2,y2,x3,y3,color,tx2,ty2,tx3,ty3,opac).
          draw_line(x3,y3,x0,y0,color,tx3,ty3,tx0,ty0,opac);
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.drawLine(fx0,dimy()-fy0,fx1,dimy()-fy1);
        board.drawLine(fx1,dimy()-fy1,fx2,dimy()-fy2);
        board.drawLine(fx2,dimy()-fy2,fx3,dimy()-fy3);
        board.drawLine(fx3,dimy()-fy3,fx0,dimy()-fy0);
      } break;
      case 2: {
        draw_triangle(x0,y0,x1,y1,x2,y2,color,tx0,ty0,tx1,ty1,tx2,ty2,opac).
          draw_triangle(x0,y0,x2,y2,x3,y3,color,tx0,ty0,tx2,ty2,tx3,ty3,opac);
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.fillTriangle(fx0,dimy()-fy0,fx1,dimy()-fy1,fx2,dimy()-fy2);
        board.fillTriangle(fx0,dimy()-fy0,fx2,dimy()-fy2,fx3,dimy()-fy3);
      } break;
      case 3: {
        draw_triangle(x0,y0,x1,y1,x2,y2,color,tx0,ty0,tx1,ty1,tx2,ty2,opac,lightprops(l)).
          draw_triangle(x0,y0,x2,y2,x3,y3,color,tx0,ty0,tx2,ty2,tx3,ty3,opac,lightprops(l));
        const float lp = cimg::min(lightprops(l),1.0f);
        board.setPenColorRGBi((unsigned char)(128*lp),
                              (unsigned char)(128*lp),
                              (unsigned char)(128*lp),
                              (unsigned char)(opac*255));
        board.fillTriangle(fx0,dimy()-fy0,fx1,dimy()-fy1,fx2,dimy()-fy2);
        board.fillTriangle(fx0,dimy()-fy0,fx2,dimy()-fy2,fx3,dimy()-fy3);
      } break;
      case 4: {
        const float
          lightprop0 = lightprops(n0), lightprop1 = lightprops(n1),
          lightprop2 = lightprops(n2), lightprop3 = lightprops(n3);
        draw_triangle(x0,y0,x1,y1,x2,y2,color,tx0,ty0,tx1,ty1,tx2,ty2,lightprop0,lightprop1,lightprop2,opac).
          draw_triangle(x0,y0,x2,y2,x3,y3,color,tx0,ty0,tx2,ty2,tx3,ty3,lightprop0,lightprop2,lightprop3,opac);
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.fillGouraudTriangle(fx0,dimy()-fy0,lightprop0,
                                  fx1,dimy()-fy1,lightprop1,
                                  fx2,dimy()-fy2,lightprop2);
        board.fillGouraudTriangle(fx0,dimy()-fy0,lightprop0,
                                  fx2,dimy()-fy2,lightprop2,
                                  fx3,dimy()-fy3,lightprop3);
      } break;
      case 5: {
        const unsigned int
          lx0 = (unsigned int)lightprops(n0,0), ly0 = (unsigned int)lightprops(n0,1),
          lx1 = (unsigned int)lightprops(n1,0), ly1 = (unsigned int)lightprops(n1,1),
          lx2 = (unsigned int)lightprops(n2,0), ly2 = (unsigned int)lightprops(n2,1),
          lx3 = (unsigned int)lightprops(n3,0), ly3 = (unsigned int)lightprops(n3,1);
        draw_triangle(x0,y0,x1,y1,x2,y2,color,tx0,ty0,tx1,ty1,tx2,ty2,light_texture,lx0,ly0,lx1,ly1,lx2,ly2,opac).
          draw_triangle(x0,y0,x2,y2,x3,y3,color,tx0,ty0,tx1,ty1,tx2,ty2,light_texture,lx0,ly0,lx2,ly2,lx3,ly3,opac);
        const float
          l0 = light_texture((int)(light_texture.dimx()/2*(1+lx0)), (int)(light_texture.dimy()/2*(1+ly0))),
          l1 = light_texture((int)(light_texture.dimx()/2*(1+lx1)), (int)(light_texture.dimy()/2*(1+ly1))),
          l2 = light_texture((int)(light_texture.dimx()/2*(1+lx2)), (int)(light_texture.dimy()/2*(1+ly2))),
          l3 = light_texture((int)(light_texture.dimx()/2*(1+lx3)), (int)(light_texture.dimy()/2*(1+ly3)));
        board.setPenColorRGBi(128,128,128,(unsigned char)(opac*255));
        board.fillGouraudTriangle(fx0,dimy()-fy0,l0,
                                  fx1,dimy()-fy1,l1,
                                  fx2,dimy()-fy2,l2);
        board.fillGouraudTriangle(fx0,dimy()-fy0,l0,
                                  fx2,dimy()-fy2,l2,
                                  fx3,dimy()-fy3,l3);
      } break;
      }
    } break;
    }
  }
  }
  return *this;
}

//! Draw a 3D object in the instance image, and make a vector copy in a Board instance.
template<typename tp, typename tf, typename to>
  CImg& draw_object3d(BoardLib::Board& board, const float X, const float Y, const float Z,
                      const CImgList<tp>& points, const CImgList<tf>& primitives,
                      const CImgList<T>& colors, const CImgList<to>& opacities,
                      const unsigned int render_type=4,
                      const bool double_sided=false, const float focale=500,
                      const float lightx=0, const float lighty=0, const float lightz=-5000,
                      const float ambient_light=0.05f) {
  if (!points) return *this;
  CImg<tp> npoints(points.size,3,1,1,0);
  tp *ptrX = npoints.ptr(), *ptrY = npoints.ptr(0,1), *ptrZ = npoints.ptr(0,2);
  cimg_forX(npoints,l) {
    const CImg<tp>& point = points[l];
    const unsigned int siz = point.size();
    if (!siz)
      throw CImgArgumentException("CImg<%s>::draw_object3d() : Given points (size=%u) contains a null element at "
                                  "position %u.",pixel_type(),points.size,l);
    *(ptrZ++) = (siz>2)?point(2):0;
    *(ptrY++) = (siz>1)?point(1):0;
    *(ptrX++) = point(0);
  }
  return draw_object3d(board,X,Y,Z,npoints,primitives,colors,opacities,
                       render_type,double_sided,focale,lightx,lighty,lightz,ambient_light);
}

//! Draw a 3D object in the instance image, and make a vector copy in a Board instance.
template<typename tp, typename tf, typename to>
  CImg& draw_object3d(BoardLib::Board& board, const float X, const float Y, const float Z,
                      const CImg<tp>& points, const CImgList<tf>& primitives,
                      const CImgList<T>& colors, const CImg<to>& opacities,
                      const unsigned int render_type=4,
                      const bool double_sided=false, const float focale=500,
                      const float lightx=0, const float lighty=0, const float lightz=-5000,
                      const float ambient_light=0.05f) {
  CImgList<to> nopacities(opacities.size(),1);
  cimglist_for(nopacities,l) nopacities(l,0) = opacities(l);
  return draw_object3d(board,X,Y,Z,points,primitives,colors,nopacities,
                       render_type,double_sided,focale,lightx,lighty,lightz,ambient_light);
}

//! Draw a 3D object in the instance image, and make a vector copy in a Board instance.
template<typename tp, typename tf, typename to>
  CImg& draw_object3d(BoardLib::Board& board, const float X, const float Y, const float Z,
                      const CImgList<tp>& points, const CImgList<tf>& primitives,
                      const CImgList<T>& colors, const CImg<to>& opacities,
                      const unsigned int render_type=4,
                      const bool double_sided=false, const float focale=500,
                      const float lightx=0, const float lighty=0, const float lightz=-5000,
                      const float ambient_light=0.05f) {
  CImgList<to> nopacities(opacities.size(),1);
  { cimglist_for(nopacities,l) nopacities(l,0) = opacities(l); }
  if (!points) return *this;
  CImg<tp> npoints(points.size,3,1,1,0);
  tp *ptrX = npoints.ptr(), *ptrY = npoints.ptr(0,1), *ptrZ = npoints.ptr(0,2);
  cimg_forX(npoints,l) {
    const CImg<tp>& point = points[l];
    const unsigned int siz = point.size();
    if (!siz)
      throw CImgArgumentException("CImg<%s>::draw_object3d() : Given points (size=%u) contains a null element at "
                                  "position %u.",pixel_type(),points.size,l);
    *(ptrZ++) = (siz>2)?point(2):0;
    *(ptrY++) = (siz>1)?point(1):0;
    *(ptrX++) = point(0);
  }
  return draw_object3d(board,X,Y,Z,npoints,primitives,colors,nopacities,
                       render_type,double_sided,focale,lightx,lighty,lightz,ambient_light);
}

//! Draw a 3D object in the instance image, and make a vector copy in a Board instance.
template<typename tp, typename tf>
  CImg& draw_object3d(BoardLib::Board& board, const float X, const float Y, const float Z,
                      const tp& points, const CImgList<tf>& primitives,
                      const CImgList<T>& colors,
                      const unsigned int render_type=4,
                      const bool double_sided=false, const float focale=500,
                      const float lightx=0, const float lighty=0, const float lightz=-5000,
                      const float ambient_light=0.05f, const float opacity=1.0f) {
  return draw_object3d(board,X,Y,Z,points,primitives,colors,
                       CImg<float>(primitives.size,1,1,1,opacity),
                       render_type,double_sided,focale,lightx,lighty,lightz,
                       ambient_light);
}

#endif
//-------------------------
// End using Board Library
//-------------------------

//------------------------------
// End of the Toolbox3D plug-in
//------------------------------
#endif
