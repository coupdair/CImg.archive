/*-----------------------------------------------------------------------------

  File        : deprecated.h

  Description : File defining several macros ans functions
               to ensure backward compatibility with older versions of CImg.

  Copyright  : David Tschumperle - http://www.greyc.ensicaen.fr/~dtschump/

  This software is governed by the CeCILL  license under French law and
  abiding by the rules of distribution of free software.  You can  use,
  modify and/ or redistribute the software under the terms of the CeCILL
  license as circulated by CEA, CNRS and INRIA at the following URL
  "http://www.cecill.info".

  As a counterpart to the access to the source code and  rights to copy,
  modify and redistribute granted by the license, users are provided only
  with a limited warranty  and the software's author,  the holder of the
  economic rights,  and the successive licensors  have only  limited
  liability.

  In this respect, the user's attention is drawn to the risks associated
  with loading,  using,  modifying and/or developing or reproducing the
  software by the user in light of its specific status of free software,
  that may mean  that it is complicated to manipulate,  and  that  also
  therefore means  that it is reserved for developers  and  experienced
  professionals having in-depth computer knowledge. Users are therefore
  encouraged to load and test the software's suitability as regards their
  requirements in conditions enabling the security of their systems and/or
  data to be ensured and,  more generally, to use and operate it in the
  same conditions as regards security.

  The fact that you are presently reading this means that you have had
  knowledge of the CeCILL license and that you accept its terms.

  ------------------------------------------------------------------------------*/

#ifndef cimg_plugin_deprecated
#define cimg_plugin_deprecated

// Deprecated macros
//------------------
#define CImgl CImgList
#define cimgl_map cimglist_for
#define cimglist_map cimglist_for
#define cimg_map cimg_for
#define cimg_mapoff cimg_foroff
#define cimg_mapX cimg_forX
#define cimg_mapY cimg_forY
#define cimg_mapZ cimg_forZ
#define cimg_mapV cimg_forV
#define cimg_mapXY cimg_forXY
#define cimg_mapXZ cimg_forXZ
#define cimg_mapXV cimg_forXV
#define cimg_mapYZ cimg_forYZ
#define cimg_mapYV cimg_forYV
#define cimg_mapZV cimg_forZV
#define cimg_mapXYZ cimg_forXYZ
#define cimg_mapXYV cimg_forXYV
#define cimg_mapXZV cimg_forXZV
#define cimg_mapYZV cimg_forYZV
#define cimg_mapXYZV cimg_forXYZV
#define cimg_imapX cimg_for_insideX
#define cimg_imapY cimg_for_insideY
#define cimg_imapZ cimg_for_insideZ
#define cimg_imapV cimg_for_insideV
#define cimg_imapXY cimg_for_insideXY
#define cimg_imapXYZ cimg_for_insideXYZ
#define cimg_bmapX cimg_for_borderX
#define cimg_bmapY cimg_for_borderY
#define cimg_bmapZ cimg_for_borderZ
#define cimg_bmapV cimg_for_borderV
#define cimg_bmapXY cimg_for_borderXY
#define cimg_bmapXYZ cimg_for_borderXYZ
#define cimg_2mapX cimg_for2X
#define cimg_2mapY cimg_for2Y
#define cimg_2mapZ cimg_for2Z
#define cimg_2mapXY cimg_for2XY
#define cimg_2mapXZ cimg_for2XZ
#define cimg_2mapYZ cimg_for2YZ
#define cimg_2mapXYZ cimg_for2XYZ
#define cimg_3mapX cimg_for3X
#define cimg_3mapY cimg_for3Y
#define cimg_3mapZ cimg_for3Z
#define cimg_3mapXY cimg_for3XY
#define cimg_3mapXZ cimg_for3XZ
#define cimg_3mapYZ cimg_for3YZ
#define cimg_3mapXYZ cimg_for3XYZ
#define cimg_4mapX cimg_for4X
#define cimg_4mapY cimg_for4Y
#define cimg_4mapZ cimg_for4Z
#define cimg_4mapXY cimg_for4XY
#define cimg_4mapXZ cimg_for4XZ
#define cimg_4mapYZ cimg_for4YZ
#define cimg_4mapXYZ cimg_for4XYZ
#define cimg_5mapX cimg_for5X
#define cimg_5mapY cimg_for5Y
#define cimg_5mapZ cimg_for5Z
#define cimg_5mapXY cimg_for5XY
#define cimg_5mapXZ cimg_for5XZ
#define cimg_5mapYZ cimg_for5YZ
#define cimg_5mapXYZ cimg_for5XYZ
#define cimg_map2x2x1 cimg_for2x2
#define cimg_map3x3x1 cimg_for3x3
#define cimg_map4x4x1 cimg_for4x4
#define cimg_map5x5x1 cimg_for5x5
#define cimg_map2x2 cimg_for2x2
#define cimg_map3x3 cimg_for3x3
#define cimg_map4x4 cimg_for4x4
#define cimg_map5x5 cimg_for5x5
#define cimg_map3x3x3 cimg_for3x3x3
#define cimg_map2x2x2 cimg_for2x2x2
#define CImg_2x2x1 CImg_2x2
#define CImg_3x3x1 CImg_3x3
#define CImg_4x4x1 CImg_4x4
#define CImg_5x5x1 CImg_5x5
#define scroll translate
#define cimg_convert_path cimg_imagemagick_path
#define load_convert load_imagemagick
#define save_convert save_imagemagick

// Deprecated functions
//----------------------
const CImg& feature_selection(int* const selection, const int feature_type, CImgDisplay &disp,
                              unsigned int *const XYZ=0,const unsigned char *const color=0) const {
  if (is_empty())
    throw CImgInstanceException("CImg<%s>::feature_selection() : Instance image (%u,%u,%u,%u,%p) is empty.",
                                pixel_type(),width,height,depth,dim,data);
  const unsigned int
    old_events = disp.events,
    old_normalization = disp.normalization,
    hatch = 0x55555555;
  bool old_is_resized = disp.is_resized;
  disp.events = 3;
  disp.normalization = 0;
  disp.show().key = 0;
  unsigned char fgcolor[3] = { 255,255,105 }, bgcolor[3] = { 0,0,0 };
  if (color) std::memcpy(fgcolor,color,sizeof(unsigned char)*cimg::min(3,dimv()));
  int area = 0, clicked_area = 0, phase = 0,
    X0 = (int)((XYZ?XYZ[0]:width/2)%width), Y0 = (int)((XYZ?XYZ[1]:height/2)%height), Z0 = (int)((XYZ?XYZ[2]:depth/2)%depth),
    X1 =-1, Y1 = -1, Z1 = -1,
    X = -1, Y = -1, Z = -1,
    oX = X, oY = Y, oZ = Z;
  unsigned int old_button = 0, key = 0;
  bool feature_selected = false, text_down = false;
  CImg<unsigned char> visu, visu0;
  char text[1024] = { 0 };
  while (!key && !disp.is_closed && !feature_selected) {
    oX = X; oY = Y; oZ = Z;
    int mx = disp.mouse_x, my = disp.mouse_y;
    const int mX = mx*(width+(depth>1?depth:0))/disp.width, mY = my*(height+(depth>1?depth:0))/disp.height;
    area = 0;
    if (mX<dimx() && mY<dimy())  { area = 1; X = mX; Y = mY; Z = phase?Z1:Z0; }
    if (mX<dimx() && mY>=dimy()) { area = 2; X = mX; Z = mY-height; Y = phase?Y1:Y0; }
    if (mX>=dimx() && mY<dimy()) { area = 3; Y = mY; Z = mX-width; X = phase?X1:X0; }
    key = disp.key;
    if (key && key!=cimg::keyCTRLLEFT) {
      if (disp.is_key(cimg::keyCTRLLEFT)) {
        switch (key) {
        case cimg::keyARROWLEFT:
        case cimg::keyARROWDOWN: disp.wheel--; break;
        case cimg::keyARROWRIGHT:
        case cimg::keyARROWUP: disp.wheel++; break;
        case cimg::keyD: if (disp.is_fullscreen) disp.toggle_fullscreen(); disp.resize(-200,-200); disp.is_resized = true; break;
        case cimg::keyC: if (disp.is_fullscreen) disp.toggle_fullscreen(); disp.resize(-50,-50); disp.is_resized = true; break;
        case cimg::keyR: if (disp.is_fullscreen) disp.toggle_fullscreen(); disp.resize(*this); disp.is_resized = true; break;
        case cimg::keyF:
          disp.resize(disp.screen_dimx(),disp.screen_dimy()).toggle_fullscreen();
          disp.is_resized = true;
          break;
        case cimg::keyS: {
          static unsigned int snap_number = 0;
          char filename[32] = {0};
          std::FILE *file;
          do {
            std::sprintf(filename,"CImg_%.4u.bmp",snap_number++);
            if ((file=std::fopen(filename,"r"))!=0) std::fclose(file);
          } while (file);
          if (!visu0.is_empty()) visu0.save(filename);
        } break;
        default: break;
        }
        key = disp.key = 0;
      }
    } else key = 0;
    if (!area) mx = my = X = Y = Z = -1;
    else {
      if (disp.button&1 && phase<2) { X1 = X; Y1 = Y; Z1 = Z; }
      if (!(disp.button&1) && phase>=2) {
        switch (clicked_area) {
        case 1: Z1 = Z; break;
        case 2: Y1 = Y; break;
        case 3: X1 = X; break;
        }
      }
      if (disp.button&2) { if (phase) { X1 = X; Y1 = Y; Z1 = Z; } else { X0 = X; Y0 = Y; Z0 = Z; } }
      if (disp.button&4) { oX = X = X0; oY = Y = Y0; oZ = Z = Z0; phase = 0; visu.assign(); }
      if (disp.wheel) {
        switch (area) {
        case 1: if (phase) Z = (Z1+=disp.wheel); else Z = (Z0+=disp.wheel); break;
        case 2: if (phase) Y = (Y1+=disp.wheel); else Y = (Y0+=disp.wheel); break;
        case 3: if (phase) X = (X1+=disp.wheel); else X = (X0+=disp.wheel); break;
        default: break;
        }
        disp.wheel = 0;
      }
      if ((disp.button&1)!=old_button) {
        switch (phase++) {
        case 0: X0 = X1 = X; Y0 = Y1 = Y; Z0 = Z1 = Z; clicked_area = area; break;
        case 1: X1 = X; Y1 = Y; Z1 = Z; break;
        default: break;
        }
        old_button = disp.button&1;
      }
      if (depth>1 && (X!=oX || Y!=oY || Z!=oZ)) visu0.assign();
    }
    if (phase) {
      if (!feature_type) feature_selected = phase?true:false;
      else {
        if (depth>1) feature_selected = (phase==3)?true:false;
        else feature_selected = (phase==2)?true:false;
      }
    }
    if (X0<0) X0 = 0; if (X0>=(int)width) X0 = (int)width-1; if (Y0<0) Y0 = 0; if (Y0>=(int)height) Y0 = (int)height-1;
    if (Z0<0) Z0 = 0; if (Z0>=(int)depth) Z0 = (int)depth-1;
    if (X1<1) X1 = 0; if (X1>=(int)width) X1 = (int)width-1; if (Y1<0) Y1 = 0; if (Y1>=(int)height) Y1 = (int)height-1;
    if (Z1<0) Z1 = 0; if (Z1>=(int)depth) Z1 = (int)depth-1;
    if (oX!=X || oY!=Y || oZ!=Z || visu0.is_empty()) {
      if (visu0.is_empty()) {
        CImg<T> tmp;
        if (depth==1) tmp = get_resize(disp.width,disp.height,1,cimg::min(3,dimv()));
        else tmp = (!phase?get_projections2d(X0,Y0,Z0):get_projections2d(X1,Y1,Z1)).get_resize(disp.width,disp.height,1,cimg::min(3,dimv()));
        if (old_normalization) {
          if (old_normalization<3 || cimg::type<T>::is_float()) {
            if (sizeof(T)>1) visu0.assign(tmp.normalize(0,255));
            else visu0.assign(tmp).normalize(0,255);
          } else {
            if (cimg::type<T>::id()!=cimg::type<unsigned char>::id()) {
              const float m = cimg::type<T>::min(), M = cimg::type<T>::max();
              visu0.assign((CImg<float>(tmp)-=m)*=255.0f/(M-m));
            } else visu0.assign(tmp);
          }
        } else visu0.assign(tmp);
      }
      visu = visu0;

      const int d=(depth>1)?depth:0;
      if (phase) switch (feature_type) {
      case 1: {
        const int
          x0=(int)((X0+0.5f)*disp.width/(width+d)), y0=(int)((Y0+0.5f)*disp.height/(height+d)),
          x1=(int)((X1+0.5f)*disp.width/(width+d)), y1=(int)((Y1+0.5f)*disp.height/(height+d));
        visu.draw_arrow(x0,y0,x1,y1,fgcolor,30.0f,5.0f,hatch);
        if (d) {
          const int zx0=(int)((width+Z0+0.5f)*disp.width/(width+d)), zx1=(int)((width+Z1+0.5f)*disp.width/(width+d)),
            zy0=(int)((height+Z0+0.5f)*disp.height/(height+d)), zy1=(int)((height+Z1+0.5f)*disp.height/(height+d));
          visu.draw_arrow(zx0,y0,zx1,y1,fgcolor,30.0f,5.0f,hatch).draw_arrow(x0,zy0,x1,zy1,fgcolor,30.0f,5.0f,hatch);
        }
      } break;
      case 2: {
        const int
          x0=(X0<X1?X0:X1)*disp.width/(width+d),
          y0=(Y0<Y1?Y0:Y1)*disp.height/(height+d),
          x1=((X0<X1?X1:X0)+1)*disp.width/(width+d)-1,
          y1=((Y0<Y1?Y1:Y0)+1)*disp.height/(height+d)-1;
        visu.draw_rectangle(x0,y0,x1,y1,fgcolor,0.2f).draw_line(x0,y0,x1,y0,fgcolor,hatch).
          draw_line(x1,y0,x1,y1,fgcolor,hatch).draw_line(x1,y1,x0,y1,fgcolor,hatch).draw_line(x0,y1,x0,y0,fgcolor,hatch);
        if (d) {
          const int
            zx0=(int)((width+(Z0<Z1?Z0:Z1))*disp.width/(width+d)),
            zy0=(int)((height+(Z0<Z1?Z0:Z1))*disp.height/(height+d)),
            zx1=(int)((width+(Z0<Z1?Z1:Z0)+1)*disp.width/(width+d))-1,
            zy1=(int)((height+(Z0<Z1?Z1:Z0)+1)*disp.height/(height+d))-1;
          visu.draw_rectangle(zx0,y0,zx1,y1,fgcolor,0.2f).draw_line(zx0,y0,zx1,y0,fgcolor,hatch).
            draw_line(zx1,y0,zx1,y1,fgcolor,hatch).draw_line(zx1,y1,zx0,y1,fgcolor,hatch).draw_line(zx0,y1,zx0,y0,fgcolor,hatch);
          visu.draw_rectangle(x0,zy0,x1,zy1,fgcolor,0.2f).draw_line(x0,zy0,x1,zy0,fgcolor,hatch).
            draw_line(x1,zy0,x1,zy1,fgcolor,hatch).draw_line(x1,zy1,x0,zy1,fgcolor,hatch).draw_line(x0,zy1,x0,zy0,fgcolor,hatch);
        }
      } break;
      case 3: {
        const int
          x0=X0*disp.width/(width+d),
          y0=Y0*disp.height/(height+d),
          x1=X1*disp.width/(width+d)-1,
          y1=Y1*disp.height/(height+d)-1;
        visu.draw_ellipse(x0,y0,(float)(x1-x0),(float)(y1-y0),1.0f,0.0f,fgcolor,0L,0.2f).
          draw_ellipse(x0,y0,(float)(x1-x0),(float)(y1-y0),1.0f,0.0f,fgcolor,hatch);
        if (d) {
          const int
            zx0=(int)((width+Z0)*disp.width/(width+d)),
            zy0=(int)((height+Z0)*disp.height/(height+d)),
            zx1=(int)((width+Z1+1)*disp.width/(width+d))-1,
            zy1=(int)((height+Z1+1)*disp.height/(height+d))-1;
          visu.draw_ellipse(zx0,y0,(float)(zx1-zx0),(float)(y1-y0),1.0f,0.0f,fgcolor,0L,0.2f).
            draw_ellipse(zx0,y0,(float)(zx1-zx0),(float)(y1-y0),1.0f,0.0f,fgcolor,hatch).
            draw_ellipse(x0,zy0,(float)(x1-x0),(float)(zy1-zy0),1.0f,0.0f,fgcolor,0L,0.2f).
            draw_ellipse(x0,zy0,(float)(x1-x0),(float)(zy1-zy0),1.0f,0.0f,fgcolor,hatch);
        }
      } break;
      }

      if (my<12) text_down = true;
      if (my>=visu.dimy()-11) text_down = false;
      if (!feature_type || !phase) {
        if (X>=0 && Y>=0 && Z>=0 && X<(int)width && Y<(int)height && Z<(int)depth) {
          if (depth>1) std::sprintf(text,"Coords (%d,%d,%d)={ ",X,Y,Z); else std::sprintf(text,"Coords (%d,%d)={ ",X,Y);
          char *ctext = text + cimg::strlen(text), *const ltext = text+512;
          for (unsigned int k=0; k<dim && ctext<ltext; k++) {
            std::sprintf(ctext,"%g ",(double)(*this)(X,Y,Z,k));
            ctext = text + cimg::strlen(text);
          }
          std::sprintf(text+cimg::strlen(text),"}");
        }
      } else switch (feature_type) {
      case 1: {
        const double dX=(double)(X0-X1), dY=(double)(Y0-Y1), dZ=(double)(Z0-Z1), norm = std::sqrt(dX*dX+dY*dY+dZ*dZ);
        if (depth>1) std::sprintf(text,"Vect (%d,%d,%d)-(%d,%d,%d), norm=%g",X0,Y0,Z0,X1,Y1,Z1,norm);
        else std::sprintf(text,"Vect (%d,%d)-(%d,%d), norm=%g",X0,Y0,X1,Y1,norm);
      } break;
      case 2:
        if (depth>1) std::sprintf(text,"Box (%d,%d,%d)-(%d,%d,%d), Size=(%d,%d,%d)",
                                  X0<X1?X0:X1,Y0<Y1?Y0:Y1,Z0<Z1?Z0:Z1,
                                  X0<X1?X1:X0,Y0<Y1?Y1:Y0,Z0<Z1?Z1:Z0,
                                  1+cimg::abs(X0-X1),1+cimg::abs(Y0-Y1),1+cimg::abs(Z0-Z1));
        else  std::sprintf(text,"Box (%d,%d)-(%d,%d), Size=(%d,%d)",
                           X0<X1?X0:X1,Y0<Y1?Y0:Y1,X0<X1?X1:X0,Y0<Y1?Y1:Y0,1+cimg::abs(X0-X1),1+cimg::abs(Y0-Y1));
        break;
      default:
        if (depth>1) std::sprintf(text,"Ellipse (%d,%d,%d)-(%d,%d,%d), Radii=(%d,%d,%d)",
                                  X0,Y0,Z0,X1,Y1,Z1,1+cimg::abs(X0-X1),1+cimg::abs(Y0-Y1),1+cimg::abs(Z0-Z1));
        else  std::sprintf(text,"Ellipse (%d,%d)-(%d,%d), Radii=(%d,%d)",
                           X0,Y0,X1,Y1,1+cimg::abs(X0-X1),1+cimg::abs(Y0-Y1));

        break;
      }
      if (phase || (mx>=0 && my>=0)) visu.draw_text(text,0,text_down?visu.dimy()-11:0,fgcolor,bgcolor,11,0.7f);
      disp.display(visu).wait(25);
    } else disp.wait();

    if (disp.is_resized) { disp.resize(false); old_is_resized = true; disp.is_resized = false; visu0.assign(); }
  }
  if (XYZ) { XYZ[0] = (unsigned int)X0; XYZ[1] = (unsigned int)Y0; XYZ[2] = (unsigned int)Z0; }
  if (feature_selected) {
    if (feature_type==2) {
      if (X0>X1) cimg::swap(X0,X1);
      if (Y0>Y1) cimg::swap(Y0,Y1);
      if (Z0>Z1) cimg::swap(Z0,Z1);
    }
    if (selection) {
      if (X1<0 || Y1<0 || Z1<0) X0=Y0=Z0=X1=Y1=Z1=-1;
      switch(feature_type) {
      case 1:
      case 2:  selection[3] = X1; selection[4] = Y1; selection[5] = Z1;
      default: selection[0] = X0; selection[1] = Y0; selection[2] = Z0;
      }
    }
  } else if (selection) selection[0]=selection[1]=selection[2]=selection[3]=selection[4]=selection[5]=-1;
  disp.button = 0;
  disp.events = old_events;
  disp.normalization = old_normalization;
  disp.is_resized = old_is_resized;
  disp.key = key;
  return *this;
}

const CImg& feature_selection(int *const selection, const int feature_type,
                              unsigned int *const XYZ=0,const unsigned char *const color=0) const {
  unsigned int w = width + (depth>1?depth:0), h = height + (depth>1?depth:0);
  const unsigned int dmin = cimg::min(w,h), minsiz = 256;
  if (dmin<minsiz) { w=w*minsiz/dmin; h=h*minsiz/dmin; }
  const unsigned int dmax = cimg::max(w,h), maxsiz = 1024;
  if (dmax>maxsiz) { w=w*maxsiz/dmax; h=h*maxsiz/dmax; }
  CImgDisplay disp(w,h," ",1,3);
  return feature_selection(selection,feature_type,disp,XYZ,color);
}

#else
#ifndef cimg_plugin_deprecated2
#define cimg_plugin_deprecated2

namespace cimg_library {

  /*
   #----------------------------------------
   #
   #
   #
   # Definition of the CImgStats structure
   #
   #
   #
   #----------------------------------------
   */
  //! Class used to compute basic statistics on pixel values of a \ref CImg image.
  /**
      Constructing a CImgStats instance from an image CImg<T> or a list CImgList<T>
      will compute the minimum, maximum and average pixel values of the input object.
      Optionally, the variance of the pixel values can be computed.
      Coordinates of the pixels whose values are minimum and maximum are also stored.
      The example below shows how to use CImgStats objects to retrieve simple statistics of an image :
      \code
      const CImg<float> img("my_image.jpg");                 // Read JPEG image file.
      const CImgStats stats(img);                            // Compute basic statistics on the image.
      stats.print("My statistics");                          // Display statistics.
      std::printf("Max-Min = %lf",stats.max-stats.min);      // Compute the difference between extremum values.
      \endcode

      Note that statistics are computed by considering the set of \a scalar values of the image pixels.
      No vector-valued statistics are computed.
  **/
  struct CImgStats {
    double min;                 //!< Minimum of the pixel values.
    double max;                 //!< Maximum of the pixel values.
    double mean;                //!< Mean of the pixel values.
    double variance;            //!< Variance of the pixel values.
    int xmin;                   //!< X-coordinate of the pixel with minimum value.
    int ymin;                   //!< Y-coordinate of the pixel with minimum value.
    int zmin;                   //!< Z-coordinate of the pixel with minimum value.
    int vmin;                   //!< V-coordinate of the pixel with minimum value.
    int lmin;                   //!< Image number (for a list) containing the minimum pixel.
    int xmax;                   //!< X-coordinate of the pixel with maximum value.
    int ymax;                   //!< Y-coordinate of the pixel with maximum value.
    int zmax;                   //!< Z-coordinate of the pixel with maximum value.
    int vmax;                   //!< V-coordinate of the pixel with maximum value.
    int lmax;                   //!< Image number (for a list) containing the maximum pixel.

#ifdef cimgstats_plugin
#include cimgstats_plugin
#endif

    //! Default constructor.
    CImgStats():min(0),max(0),mean(0),variance(0),xmin(-1),ymin(-1),zmin(-1),vmin(-1),lmin(-1),
                xmax(-1),ymax(-1),zmax(-1),vmax(-1),lmax(-1) {}

    //! In-place version of the default constructor
    CImgStats& assign() {
      min = max = mean = variance = 0;
      xmin = ymin = zmin = vmin = lmin = xmax = ymax = zmax = vmax = lmax = -1;
      return *this;
    }

    //! Copy constructor.
    CImgStats(const CImgStats& stats) {
      assign(stats);
    };

    //! In-place version of the copy constructor.
    CImgStats& assign(const CImgStats& stats) {
      min = stats.min;
      max = stats.max;
      mean = stats.mean;
      variance = stats.variance;
      xmin = stats.xmin; ymin = stats.ymin; zmin = stats.zmin; vmin = stats.vmin; lmin = stats.lmin;
      xmax = stats.xmax; ymax = stats.ymax; zmax = stats.zmax; vmax = stats.vmax; lmax = stats.lmax;
      return *this;
    }

    //! Constructor that computes statistics of an input image \p img.
    /**
        \param img The input image.
        \param compute_variance If true, the \c variance field is computed, else it is set to 0.
    **/
    template<typename T> CImgStats(const CImg<T>& img, const bool compute_variance=true) {
      assign(img,compute_variance);
    }

    //! In-place version of the previous constructor.
    template<typename T> CImgStats& assign(const CImg<T>& img, const bool compute_variance=true) {
      if (!img)
        throw CImgArgumentException("CImgStats::CImgStats() : Specified input image (%u,%u,%u,%u,%p) is empty.",
                                    img.width,img.height,img.depth,img.dim,img.data);
      mean = variance = 0;
      lmin = lmax = -1;
      T pmin=img[0], pmax=pmin, *ptrmin=img.data, *ptrmax=ptrmin;
      cimg_for(img,ptr,T) {
        const T& a=*ptr;
        mean+=(double)a;
        if (a<pmin) { pmin=a; ptrmin = ptr; }
        if (a>pmax) { pmax=a; ptrmax = ptr; }
      }
      mean/=img.size();
      min=(double)pmin;
      max=(double)pmax;
      unsigned long offmin = (unsigned long)(ptrmin-img.data), offmax = (unsigned long)(ptrmax-img.data);
      const unsigned long whz = img.width*img.height*img.depth, wh = img.width*img.height;
      vmin = offmin/whz; offmin%=whz; zmin = offmin/wh; offmin%=wh; ymin = offmin/img.width; xmin = offmin%img.width;
      vmax = offmax/whz; offmax%=whz; zmax = offmax/wh; offmax%=wh; ymax = offmax/img.width; xmax = offmax%img.width;
      if (compute_variance) {
        cimg_for(img,ptr,T) { const double tmpf=(*ptr)-mean; variance+=tmpf*tmpf; }
        const unsigned int siz = img.size();
        if (siz>1) variance/=(siz-1); else variance = 0;
      }
      return *this;
    }

    //! Constructor that computes statistics of an input image list \p list.
    /**
       \param list The input list of images.
       \param compute_variance If true, the \c variance field is computed, else it is set to 0.
    **/
    template<typename T> CImgStats(const CImgList<T>& list, const bool compute_variance=true) {
      assign(list,compute_variance);
    }

    //! In-place version of the previous constructor.
    template<typename T> CImgStats& assign(const CImgList<T>& list, const bool compute_variance=true) {
      if (!list)
        throw CImgArgumentException("CImgStats::CImgStats() : Specified input list (%u,%p) is empty.",
                                    list.size,list.data);
      mean = variance = lmin = lmax = 0;
      T pmin = list[0][0], pmax = pmin, *ptrmin = list[0].data, *ptrmax = ptrmin;
      int psize = 0;
      cimglist_for(list,l) {
        cimg_for(list[l],ptr,T) {
          const T& a=*ptr;
          mean+=(double)a;
          if (a<pmin) { pmin=a; ptrmin = ptr; lmin = l; }
          if (a>pmax) { pmax=a; ptrmax = ptr; lmax = l; }
        }
        psize+=list[l].size();
      }
      mean/=psize;
      min=(double)pmin;
      max=(double)pmax;
      const CImg<T> &imin = list[lmin], &imax = list[lmax];
      unsigned long offmin = (ptrmin-imin.data), offmax = (ptrmax-imax.data);
      const unsigned long whz1 = imin.width*imin.height*imin.depth, wh1 = imin.width*imin.height;
      vmin = offmin/whz1; offmin%=whz1; zmin = offmin/wh1; offmin%=wh1; ymin = offmin/imin.width; xmin = offmin%imin.width;
      const unsigned long whz2 = imax.width*imax.height*imax.depth, wh2 = imax.width*imax.height;
      vmax = offmax/whz2; offmax%=whz2; zmax = offmax/wh2; offmax%=wh2; ymax = offmax/imax.width; xmax = offmax%imax.width;
      if (compute_variance) {
        cimglist_for(list,l) cimg_for(list[l],ptr,T) { const double tmpf=(*ptr)-mean; variance+=tmpf*tmpf; }
        if (psize>1) variance/=(psize-1); else variance = 0;
      }
      return *this;
    }

    //! Assignment operator.
    CImgStats& operator=(const CImgStats& stats) {
      return assign(stats);
    }

    //! Return true if the current instance contains valid statistics
    bool is_empty() const {
      return (xmin>=0 && ymin>=0 && zmin>=0 && vmin>=0 && xmax>=0 && ymax>=0 && zmax>=0 && vmax>=0);
    }

    //! Casting operator
    operator bool() const {
      return !is_empty();
    }

    //! Print the current statistics.
    /**
       Printing is done on the standard error output.
    **/
    const CImgStats& print(const char* title=0) const {
      if (lmin>=0 && lmax>=0)
        std::fprintf(stderr,"%-8s(this=%p) : { min=%g, mean=%g [var=%g], max=%g, "
                     "pmin=[%d](%d,%d,%d,%d), pmax=[%d](%d,%d,%d,%d) }\n",
                     title?title:"CImgStats",(void*)this,min,mean,variance,max,
                     lmin,xmin,ymin,zmin,vmin,lmax,xmax,ymax,zmax,vmax);
      else
        std::fprintf(stderr,"%-8s(this=%p) : { min=%g, mean=%g [var=%g], max=%g, "
                     "pmin=(%d,%d,%d,%d), pmax=(%d,%d,%d,%d) }\n",
                     title?title:"CImgStats",(void*)this,min,mean,variance,max,
                     xmin,ymin,zmin,vmin,xmax,ymax,zmax,vmax);
      return *this;
    }

  };

}

#endif
#endif
